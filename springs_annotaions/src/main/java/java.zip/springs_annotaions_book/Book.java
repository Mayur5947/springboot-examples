package springs_annotaions_book;

import org.springframework.stereotype.Component;

@Component
public class Book {

	public void nameOfBook() {
		System.out.println("**********BHAGWADGITA**********");
	}
}
