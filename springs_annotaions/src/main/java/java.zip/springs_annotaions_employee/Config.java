package springs_annotaions_employee;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;import org.springframework.stereotype.Component;

@Configuration
@ComponentScan(basePackages = {"springs_annotaions_employee"})
public class Config {

}
