package springs_annotaions_employee;

public interface BankAccount {
	void balance();
}
