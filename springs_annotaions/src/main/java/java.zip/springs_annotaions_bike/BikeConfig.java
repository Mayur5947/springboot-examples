package springs_annotaions_bike;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"springs_annotaions_bike"})
public class BikeConfig {

}
