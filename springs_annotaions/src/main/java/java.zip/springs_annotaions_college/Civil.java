package springs_annotaions_college;

import org.springframework.stereotype.Component;

@Component
public class Civil implements Student {
	public void stream() {
		System.out.println("Civil Mistris");
	}
}
