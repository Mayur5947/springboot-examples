package springs_annotaions_college;

public class Entc implements Student {
	public void stream() {
		System.out.println("Entc Students");
	}
}
