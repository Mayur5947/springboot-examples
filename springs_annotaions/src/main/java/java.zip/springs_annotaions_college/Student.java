package springs_annotaions_college;

public interface Student {

	void stream();
}
